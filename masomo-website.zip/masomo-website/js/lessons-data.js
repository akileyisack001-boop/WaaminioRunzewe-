// =====================================================
//  ORODHA YA MASOMO
//  Ongeza somo jipya hapa chini.
//  Kisha unda faili la HTML ndani ya folda ya /masomo/
// =====================================================

const lessons = [
  {
    id: "01",
    title: "Utangulizi wa Masomo",
    description: "Karibu! Hapa utajifunza jinsi ya kutumia tovuti hii na jinsi masomo yanavyopangwa.",
    file: "masomo/somo-01.html",
    date: "2025-01-15"
  },
  {
    id: "02",
    title: "Mfano wa Somo la Pili",
    description: "Hili ni somo la mfano linaloonyesha jinsi ya kuweka maandishi, HTML, video na sauti.",
    file: "masomo/somo-02.html",
    date: "2025-01-20"
  }
  // Ongeza masomo mengine hapa. Mfano:
  // {
  //   id: "03",
  //   title: "Jina la Somo",
  //   description: "Maelezo mafupi ya somo...",
  //   file: "masomo/somo-03.html",
  //   date: "2025-02-01"
  // },
];

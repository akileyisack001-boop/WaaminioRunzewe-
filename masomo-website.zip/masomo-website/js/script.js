// Onyesha orodha ya masomo kwenye ukurasa mkuu
document.addEventListener('DOMContentLoaded', function () {
  const lessonsList = document.getElementById('lessons-list');
  const yearEl = document.getElementById('year');

  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  if (!lessonsList || typeof lessons === 'undefined') return;

  // Panga masomo kuanzia namba ndogo kwenda juu
  const sorted = [...lessons].sort((a, b) => a.id.localeCompare(b.id));

  sorted.forEach(lesson => {
    const card = document.createElement('article');
    card.className = 'lesson-card';
    card.innerHTML = `
      <span class="lesson-number">Somo ${lesson.id}</span>
      <h3>${lesson.title}</h3>
      <p>${lesson.description}</p>
      <a href="${lesson.file}" class="btn">Soma Somo →</a>
    `;
    lessonsList.appendChild(card);
  });
});
